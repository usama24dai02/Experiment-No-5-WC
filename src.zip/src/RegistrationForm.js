import React, { useState } from "react";

function RegistrationForm() {
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    password: "",
    mobile: "",
    address: "",
  });

  const [errors, setErrors] = useState({});

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const validate = () => {
    let tempErrors = {};
    let isValid = true;

    // First Name
    if (!/^[A-Za-z]{6,}$/.test(formData.firstName)) {
      tempErrors.firstName = "First Name must be at least 6 alphabets.";
      isValid = false;
    }

    // Last Name
    if (!formData.lastName) {
      tempErrors.lastName = "Last Name cannot be empty.";
      isValid = false;
    }

    // Password
    if (formData.password.length < 6) {
      tempErrors.password = "Password must be at least 6 characters.";
      isValid = false;
    }

    // Email
    const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$/;
    if (!emailPattern.test(formData.email)) {
      tempErrors.email = "Enter a valid email address.";
      isValid = false;
    }

    // Mobile
    if (!/^\d{10}$/.test(formData.mobile)) {
      tempErrors.mobile = "Mobile number must be 10 digits.";
      isValid = false;
    }

    // Address
    if (!formData.address) {
      tempErrors.address = "Address cannot be empty.";
      isValid = false;
    }

    setErrors(tempErrors);
    return isValid;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (validate()) {
      alert("Registration Successful!");
      setFormData({
        firstName: "",
        lastName: "",
        email: "",
        password: "",
        mobile: "",
        address: "",
      });
      setErrors({});
    }
  };

  return (
    <div style={{ maxWidth: "500px", margin: "30px auto", padding: "20px", border: "1px solid #ccc", borderRadius: "10px", background: "#f9f9f9" }}>
      <h2 style={{ textAlign: "center", color: "#004c99" }}>Registration Form</h2>
      <form onSubmit={handleSubmit}>
        <label>First Name:</label>
        <input type="text" name="firstName" value={formData.firstName} onChange={handleChange} />
        <div style={{ color: "red", fontSize: "14px" }}>{errors.firstName}</div>

        <label>Last Name:</label>
        <input type="text" name="lastName" value={formData.lastName} onChange={handleChange} />
        <div style={{ color: "red", fontSize: "14px" }}>{errors.lastName}</div>

        <label>Email:</label>
        <input type="text" name="email" value={formData.email} onChange={handleChange} />
        <div style={{ color: "red", fontSize: "14px" }}>{errors.email}</div>

        <label>Password:</label>
        <input type="password" name="password" value={formData.password} onChange={handleChange} />
        <div style={{ color: "red", fontSize: "14px" }}>{errors.password}</div>

        <label>Mobile:</label>
        <input type="text" name="mobile" value={formData.mobile} onChange={handleChange} />
        <div style={{ color: "red", fontSize: "14px" }}>{errors.mobile}</div>

        <label>Address:</label>
        <textarea name="address" value={formData.address} onChange={handleChange}></textarea>
        <div style={{ color: "red", fontSize: "14px" }}>{errors.address}</div>

        <button type="submit" style={{ width: "100%", padding: "10px", backgroundColor: "#004c99", color: "white", marginTop: "10px", border: "none", borderRadius: "5px" }}>Register</button>
      </form>
    </div>
  );
}

export default RegistrationForm;
